//
//  WoodpeckerMacOS.h
//  WoodpeckerMacOS
//
//  Created by 张小刚 on 2019/5/25.
//  Copyright © 2019 lifebetter. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//! Project version number for WoodpeckerMacOS.
FOUNDATION_EXPORT double WoodpeckerMacOSVersionNumber;

//! Project version string for WoodpeckerMacOS.
FOUNDATION_EXPORT const unsigned char WoodpeckerMacOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <WoodpeckerMacOS/PublicHeader.h>


