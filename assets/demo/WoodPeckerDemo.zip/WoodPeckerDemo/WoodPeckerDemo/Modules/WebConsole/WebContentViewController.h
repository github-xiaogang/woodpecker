//
//  WebDebuggerTestViewController.h
//
//  Created by 张小刚 on 2017/12/17.
//  Copyright © 2017年 lifebetter. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WebContentViewController : UIViewController

@property (nonatomic, assign) BOOL uiwebView;

@end
