//
//  EchoService.h
//  WoodPeckerDemo
//
//  Created by 张小刚 on 2018/1/17.
//  Copyright © 2018年 lifebetter. All rights reserved.
//

#import <WoodPeckeriOS/WoodPeckeriOS.h>

/**
 show how to create a custom service
 
 http://www.woodpeck.cn/plugin.html
 */
@interface EchoService : ADHService

@end
